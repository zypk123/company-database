alter table T_SYS_ROAD_SECTION
  drop constraint ROAD_SECTION_CODE_UNIQUE cascade;